package main

import (
    "database/sql"
    "fmt"
    "log"

    "github.com/go-faker/faker/v3"
    _ "github.com/lib/pq"
)

func main() {
    db, err := sql.Open("postgres", "postgres://postgres:ertak@localhost:5432/dars?sslmode=disable")
    if err != nil {
        log.Fatal(err)
    }
    defer db.Close()

    err = db.Ping()
    if err != nil {
        log.Fatal(err)
    }

    tx, err := db.Begin()
    if err != nil {
        log.Fatal(err)
    }

    stmt, err := tx.Prepare("INSERT INTO product (id, name, category, cost) VALUES ($1, $2, $3, $4)")
    if err != nil {
        log.Fatal(err)
    }
    defer stmt.Close()

    for i := 0; i < 1000000; i++ {
        _, err = stmt.Exec(faker.FirstName(), faker.LastName(), 4234)
        if err != nil {
            log.Fatal(err)
        }
        if i%10000 == 0 {
            fmt.Println(i)
        }
    }

    err = tx.Commit()
    if err != nil {
        log.Fatal(err)
    }

    fmt.Println("Finished inserting 1,000,000 records")
}
